var searchData=
[
  ['text',['Text',['../class_text.html',1,'Text'],['../class_text.html#a0e04bdce955cb9316be164aa4b633754',1,'Text::text()']]]
];
