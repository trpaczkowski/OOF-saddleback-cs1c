var searchData=
[
  ['readshapefile',['readShapeFile',['../class_canvas.html#a22d892eac13f1073de9155f87bad9494',1,'Canvas']]],
  ['rectangle',['Rectangle',['../class_rectangle.html#a0deed87f87e92f3b48621ff91d7e544f',1,'Rectangle']]],
  ['reserve',['reserve',['../class_vec_s_t_d_1_1vector.html#ad4bcd35b6e8bc03446a294d6cad0915d',1,'VecSTD::vector']]],
  ['resize',['resize',['../class_vec_s_t_d_1_1vector.html#a5f645b420855060ff0304f5c26ccde74',1,'VecSTD::vector']]]
];
