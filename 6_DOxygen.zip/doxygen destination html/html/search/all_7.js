var searchData=
[
  ['height',['height',['../class_rectangle.html#ac564db1ed0dd61dd82a5276399bc72ad',1,'Rectangle::height()'],['../class_ellipse.html#a549345caaff869f7eef31c800e37dd38',1,'Ellipse::height()'],['../class_text.html#abff807af22e07cded3244104e845ec50',1,'Text::height()']]]
];
