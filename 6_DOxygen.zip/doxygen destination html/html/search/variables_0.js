var searchData=
[
  ['alignmentflags',['alignmentFlags',['../class_text.html#a445eff9c2d9014ab861da51332261be1',1,'Text']]]
];
