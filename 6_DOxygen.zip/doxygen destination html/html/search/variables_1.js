var searchData=
[
  ['begin',['begin',['../class_line.html#a5c5215fb3fa1161658375ea58938a2fa',1,'Line']]],
  ['brushtype',['brushType',['../class_shape.html#a7307f002d0645d5115e3a10ccace5b93',1,'Shape']]]
];
