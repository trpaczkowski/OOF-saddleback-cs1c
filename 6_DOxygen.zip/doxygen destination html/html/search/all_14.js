var searchData=
[
  ['width',['width',['../class_rectangle.html#a019ed802523594472e0032953b6062d4',1,'Rectangle::width()'],['../class_ellipse.html#a4f2fb4b634a1c37666a0f8419c4f6d39',1,'Ellipse::width()'],['../class_text.html#a430a4945727b044dcb471554b97dd4ee',1,'Text::width()']]],
  ['writeshapefile',['writeShapeFile',['../class_canvas.html#afcaca5544fa87aa41240508ee53dbc0a',1,'Canvas']]]
];
