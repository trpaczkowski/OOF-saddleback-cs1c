var searchData=
[
  ['minimumsizehint',['minimumSizeHint',['../class_canvas.html#a82f0584c434f647c22a48b0056ff7787',1,'Canvas']]],
  ['move',['move',['../class_shape.html#a3db5f98ca68650830acb9aa18342c91a',1,'Shape::move()'],['../class_line.html#a54246c0021e1081a0bf7444b2ec03c03',1,'Line::move()'],['../class_polyline.html#ad10cb49f2bc7aaf559aa53335b1a157c',1,'Polyline::move()'],['../class_polygon.html#acf876741e06618e2378244628687cec6',1,'Polygon::move()'],['../class_rectangle.html#adf946db406616d3dab7feeb33749cf18',1,'Rectangle::move()'],['../class_ellipse.html#ab00f36f8937487d5879ab92fe1290c73',1,'Ellipse::move()'],['../class_text.html#aa4df8fb0a964a132e8ea5e019940616d',1,'Text::move()']]]
];
