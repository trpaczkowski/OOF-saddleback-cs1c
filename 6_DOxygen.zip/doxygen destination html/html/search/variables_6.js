var searchData=
[
  ['numpoints',['numPoints',['../class_polyline.html#a71b2c7784b54a2c5d0abd27ec54bc3ce',1,'Polyline::numPoints()'],['../class_polygon.html#a7c0b11d2eedf0fb2e29d1f5a41906aa8',1,'Polygon::numPoints()']]]
];
