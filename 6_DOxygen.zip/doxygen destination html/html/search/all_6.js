var searchData=
[
  ['getalignment',['getAlignment',['../class_text.html#aa558de2b84b7b9f148e29ba6008f7c45',1,'Text']]],
  ['getbeginpoint',['getBeginPoint',['../class_line.html#a48a552af5d3f2eb7cbde93794171c2e6',1,'Line']]],
  ['getbrush',['getBrush',['../class_shape.html#a89bf4b5a14f75ac6215b1c0cb45d813c',1,'Shape']]],
  ['getendpoint',['getEndPoint',['../class_line.html#a571f2254d72d633d48de91c9cec79897',1,'Line']]],
  ['getfont',['getFont',['../class_text.html#a59ca98b8967dd98605745c2911ccc3bd',1,'Text']]],
  ['getheight',['getHeight',['../class_rectangle.html#a9b6909485e6cc6e33717c6fba0d29761',1,'Rectangle::getHeight()'],['../class_ellipse.html#acd5005522d00f0e3235a2d4d931c0e39',1,'Ellipse::getHeight()'],['../class_text.html#ad8f14955feaeac94cd1da811f5f05253',1,'Text::getHeight()']]],
  ['getid',['getId',['../class_shape.html#a9943196f6a4fb3c9da2a8904c1af9a18',1,'Shape']]],
  ['getlist',['GetList',['../class_canvas.html#a14feac5d8cdf745bb2a38a5bfe809fff',1,'Canvas']]],
  ['getpen',['getPen',['../class_shape.html#a16aad057da1ce3475f666cbdd27da042',1,'Shape']]],
  ['getposition',['getPosition',['../class_rectangle.html#a67d7ac4367f7cca215b9c219d2a300a6',1,'Rectangle::getPosition()'],['../class_ellipse.html#a93318fc899736839bca9f3057a694737',1,'Ellipse::getPosition()'],['../class_text.html#ac67667342ed91dd324c51523539ae3a2',1,'Text::getPosition()']]],
  ['getrealid',['getRealID',['../class_canvas.html#aff71a7137b37765c655ae8c6198d3ed5',1,'Canvas']]],
  ['getshape',['getShape',['../class_shape.html#a1df18b087647885140460dc31527d287',1,'Shape']]],
  ['getsizing',['getSizing',['../class_canvas.html#ab36448b218b6843d6efebc1e1ffbb17c',1,'Canvas']]],
  ['gettext',['getText',['../class_text.html#ab0085792ab0b2d567759d2fa871164cc',1,'Text']]],
  ['getwidth',['getWidth',['../class_rectangle.html#ab750e4f0666df9c303ad649342bf3efd',1,'Rectangle::getWidth()'],['../class_ellipse.html#a79b45a55a6dc182866659c00535bba5e',1,'Ellipse::getWidth()'],['../class_text.html#aa426e679627149ff986a2c793b2ac71d',1,'Text::getWidth()']]]
];
