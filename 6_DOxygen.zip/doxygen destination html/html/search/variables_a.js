var searchData=
[
  ['text',['text',['../class_text.html#a0e04bdce955cb9316be164aa4b633754',1,'Text']]]
];
