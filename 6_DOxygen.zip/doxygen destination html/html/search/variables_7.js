var searchData=
[
  ['painter',['painter',['../class_shape.html#a761a117dfc4b157944e512b8a4c89fde',1,'Shape']]],
  ['pentype',['penType',['../class_shape.html#aca92df91b7c624a64ab0904b1797fc60',1,'Shape']]],
  ['points',['points',['../class_polyline.html#a8b6effda6c5bcebb28d939d9f3cab088',1,'Polyline::points()'],['../class_polygon.html#ae740d596b6c25286f564daec76c5522e',1,'Polygon::points()']]],
  ['polygonpointsar',['polygonPointsAr',['../class_polygon.html#ab2cec049537296f5a16e7a5a5078e2bb',1,'Polygon']]],
  ['polylinepointsar',['polyLinePointsAr',['../class_polyline.html#a831244c576c581c05cea8862218189dc',1,'Polyline']]],
  ['position',['position',['../class_rectangle.html#ac6364744630cfcf6e17098ecbed96b58',1,'Rectangle::position()'],['../class_ellipse.html#a9d6f41ee215d62bfe65a8bac9cf5fae3',1,'Ellipse::position()'],['../class_text.html#a2f65a86f63105bcbd6bf462024a1d3a5',1,'Text::position()']]]
];
