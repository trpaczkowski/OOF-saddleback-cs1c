var searchData=
[
  ['font',['font',['../class_text.html#aafbc87056bd5a3250299f2459078bf67',1,'Text']]]
];
