# OOF-saddleback-cs1c
group project for team OOF at Saddleback College in CS1C
